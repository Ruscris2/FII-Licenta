
export default class Renderer {
  Init(): any;
  RenderLoop(loopFeedback): any;
  GetSceneManager(): any;
}
