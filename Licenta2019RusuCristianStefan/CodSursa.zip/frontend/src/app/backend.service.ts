
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import DateTimeFormat = Intl.DateTimeFormat;
import {start} from 'repl';

@Injectable()
export class BackendService {
  private apiAddress = 'http://localhost:5000/';
  private fileApiAddress = 'http://localhost:5001/';

  constructor(private httpClient: HttpClient) {}

  register(firstName: string, lastName: string, username: string, email: string, password: string, address: string,
           country: string, city: string, zipCode: string) {
    const headers = new HttpHeaders()
      .set('Content-Type', 'application/json');

    const json = {
      firstName: firstName,
      lastName: lastName,
      username: username,
      email: email,
      password: password,
      address: address,
      country: country,
      city: city,
      zipCode: zipCode
    };

    return this.httpClient.post(this.apiAddress + 'account', json, { headers: headers });
  }

  login(identifier: string, password: string) {
    const headers = new HttpHeaders()
      .set('Content-Type', 'application/json');

    const json = {
      accountIdentifier: identifier,
      password: password
    };

    return this.httpClient.post(this.apiAddress + 'token', json, { headers: headers });
  }

  accountInfo(token: string) {
    const headers = new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('Authorization', 'Bearer ' + token);

    return this.httpClient.get(this.apiAddress + 'account', { headers: headers });
  }

  pingToken(token: string) {
    const headers = new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('Authorization', 'Bearer ' + token);

    return this.httpClient.get(this.apiAddress + 'token', { headers: headers });
  }

  updateAccountInfo(token: string, firstName: string, lastName: string, country: string, city: string, address: string, zipcode: string) {
    const headers = new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('Authorization', 'Bearer ' + token);

    const json = {
      firstName: firstName,
      lastName: lastName,
      country: country,
      city: city,
      address: address,
      zipCode: zipcode
    };

    return this.httpClient.put(this.apiAddress + 'account', json, { headers: headers });
  }

  uploadRequest(token: string) {
    const headers = new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('Authorization', 'Bearer ' + token);

    return this.httpClient.get(this.apiAddress + 'upload', { headers: headers });
  }

  uploadFiles(filesJson: any) {
    const headers = new HttpHeaders()
      .set('Content-Type', 'application/json');

    return this.httpClient.post(this.fileApiAddress + 'file', filesJson, { headers: headers });
  }

  getPhotoList(token: string, page: number, entriesPerPage: number, nameFilter: string) {
    const headers = new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('Authorization', 'Bearer ' + token);

    const json = {
      page: page,
      entriesPerPage: entriesPerPage,
      nameFilter: (nameFilter === '' ? null : nameFilter)
    };

    return this.httpClient.post(this.apiAddress + 'photo', json, { headers: headers });
  }

  getLatestPhotos(token: string) {
    const headers = new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('Authorization', 'Bearer ' + token);

    return this.httpClient.get(this.apiAddress + 'photo/latest', { headers: headers });
  }

  getMostRatedPhotos(token: string) {
    const headers = new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('Authorization', 'Bearer ' + token);

    return this.httpClient.get(this.apiAddress + 'photo/mostrated', { headers: headers });
  }

  getSinglePhoto(token: string, id: number) {
    const headers = new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('Authorization', 'Bearer ' + token);

    const json = {
      id: id
    };

    return this.httpClient.post(this.apiAddress + 'photo/single', json, { headers : headers });
  }

  editSinglePhoto(token: string, id: number, name: string, descr: string) {
    const headers = new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('Authorization', 'Bearer ' + token);

    const json = {
      id: id,
      name: name,
      description: descr
    };

    return this.httpClient.put(this.apiAddress + 'photo/single', json, { headers: headers });
  }

  ratePhoto(token: string, photoId: number, value: number) {
    const headers = new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('Authorization', 'Bearer ' + token);

    const json = {
      photoId: photoId,
      value: value
    };

    return this.httpClient.post(this.apiAddress + 'photo/rate', json, { headers: headers });
  }

  commentPhoto(token: string, photoId: number, text: string) {
    const headers = new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('Authorization', 'Bearer ' + token);

    const json = {
      photoId: photoId,
      text: text
    };

    return this.httpClient.post(this.apiAddress + 'photo/comment', json, { headers: headers });
  }

  commentList(token: string, photoId: number) {
    const headers = new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('Authorization', 'Bearer ' + token);

    const json = {
      photoId: photoId
    };

    return this.httpClient.post(this.apiAddress + 'photo/commentlist', json, { headers: headers });
  }

  getActivities(token: string) {
    const headers = new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('Authorization', 'Bearer ' + token);

    return this.httpClient.get(this.apiAddress + 'activity', {headers: headers});
  }

  getLatestPhoto(token: string) {
    const headers = new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('Authorization', 'Bearer ' + token);

    return this.httpClient.get(this.apiAddress + 'photo/latestuser', {headers: headers});
  }

  getAllPhotos(token: string, nameFilter: string, startDate: Date, endDate: Date, minRating: number, maxRating: number) {
    const headers = new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('Authorization', 'Bearer ' + token);

    const json = {
      nameFilter: nameFilter,
      startDate: startDate,
      endDate: endDate,
      minRating: minRating,
      maxRating: maxRating
    };

    return this.httpClient.post(this.apiAddress + 'photo/all', json, { headers: headers });
  }

  updatePhotoTags(token: string, photoId: number, tags: string) {
    const headers = new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('Authorization', 'Bearer ' + token);

    const json = {
      photoId: photoId,
      tags: tags
    };

    return this.httpClient.post(this.apiAddress + 'photo/updatetags', json, { headers: headers });
  }

  getNewlyUploaded(token: string) {
    const headers = new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('Authorization', 'Bearer ' + token);

    return this.httpClient.get(this.apiAddress + 'photo/newlyuploaded', {headers: headers});
  }


}
