﻿
namespace backend.Controllers.DTOs
{
    public class UploadRequestDTO
    {
        public string key;
    }
}
