﻿using System;
using System.Collections.Generic;
using System.Text;

namespace backend.Controllers.DTOs
{
    public class CommentListDTO
    {
        public int PhotoId { get; set; }
    }
}
