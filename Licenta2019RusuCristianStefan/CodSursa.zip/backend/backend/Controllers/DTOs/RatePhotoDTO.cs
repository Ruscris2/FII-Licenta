﻿using System;
using System.Collections.Generic;
using System.Text;

namespace backend.Controllers.DTOs
{
    public class RatePhotoDTO
    {
        public int PhotoId { get; set; }
        public int Value { get; set; }
    }
}
