﻿using System;
using System.Collections.Generic;
using System.Text;

namespace backend.Controllers.DTOs
{
    public class CommentPhotoDTO
    {
        public int PhotoId { get; set; }
        public string Text { get; set; }
    }
}
